<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title><?php echo $_SERVER['SERVER_NAME']; ?>
		</title>
	</head>
	<body>
<h1>
	<?php echo $_SERVER['SERVER_NAME']; ?>
</h1>
</body>
</html>
